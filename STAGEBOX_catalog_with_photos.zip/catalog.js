const equipment = [
  {
    "category": "Звукове обладнання",
    "name": "Сабвуфер пасивний SB Sub118 1х18”, 4Om, 1000W",
    "price": 600,
    "slug": "сабвуфер-пасивний-sb-sub118-1х18-4om-1000w"
  },
  {
    "category": "Звукове обладнання",
    "name": "Сабвуфер пасивний Biema  SUB T182BII 2x18”, 4Om 1200W, 136dB",
    "price": 700,
    "slug": "сабвуфер-пасивний-biema-sub-t182bii-2x18-4om-1200w-136db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Сабвуфер активний Electro Voice ELX118P сабвуфер активний 18” 500W",
    "price": 600,
    "slug": "сабвуфер-активний-electro-voice-elx118p-сабвуфер-активний-18-500w"
  },
  {
    "category": "Звукове обладнання",
    "name": "Сабвуфер активний DYNACORD A118A сабвуфер активний 18” 500W",
    "price": 600,
    "slug": "сабвуфер-активний-dynacord-a118a-сабвуфер-активний-18-500w"
  },
  {
    "category": "Звукове обладнання",
    "name": "Лінійний масив Elecor la210 800W",
    "price": 800,
    "slug": "лінійний-масив-elecor-la210-800w"
  },
  {
    "category": "Звукове обладнання",
    "name": "Лінійний масив JBL VRX932 LA  800W",
    "price": 800,
    "slug": "лінійний-масив-jbl-vrx932-la-800w",
    "photo": "https://www.jbl.com/dw/image/v2/BFND_PRD/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw218a556f/JBL_VRX932LA-1_1.png?sh=535&sw=535"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система пасивна Biema  TOP 2x15”, 2x6”,1x3” 4Om 1200W, 136dB",
    "price": 500,
    "slug": "акустична-система-пасивна-biema-top-2x15-2x61x3-4om-1200w-136db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна EAW NT29 750W, 133dB",
    "price": 600,
    "slug": "акустична-система-активна-eaw-nt29-750w-133db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна FBT X-PRO 12A 750W , 127dB",
    "price": 600,
    "slug": "акустична-система-активна-fbt-x-pro-12a-750w-127db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна JBL PRX 712 750W",
    "price": 600,
    "slug": "акустична-система-активна-jbl-prx-712-750w"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна RCF 312A 350W, 127dB",
    "price": 600,
    "slug": "акустична-система-активна-rcf-312a-350w-127db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна RCF 315A 350W, 127dB`",
    "price": 600,
    "slug": "акустична-система-активна-rcf-315a-350w-127db"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна Proel WD15a Wedge монітор",
    "price": 600,
    "slug": "акустична-система-активна-proel-wd15a-wedge-монітор"
  },
  {
    "category": "Звукове обладнання",
    "name": "Акустична система активна dB Technologies Opera 402 Live",
    "price": 600,
    "slug": "акустична-система-активна-db-technologies-opera-402-live"
  },
  {
    "category": "Звукове обладнання",
    "name": "Підсилювач Behringer NX6000D 2x2000W DSP",
    "price": 700,
    "slug": "підсилювач-behringer-nx6000d-2x2000w-dsp"
  },
  {
    "category": "Звукове обладнання",
    "name": "Підсилювач Crown macro-tech 5002VZ 2x2000W 4Om",
    "price": 700,
    "slug": "підсилювач-crown-macro-tech-5002vz-2x2000w-4om"
  },
  {
    "category": "Звукове обладнання",
    "name": "Підсилювач Powersoft X4 DSP+ETH",
    "price": 3000,
    "slug": "підсилювач-powersoft-x4-dspeth"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Behringer WING Compact+Dante карта розширення",
    "price": 3500,
    "slug": "behringer-wing-compactdante-карта-розширення",
    "photo": "https://cdn-media.empowertribe.com/5ba56d7398a6fcb81524b66ddd5aba6a/Image_BE_0603-AEV_WING-COMPACT_Media-Top-Front.webp"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Behringer WING Rack",
    "price": 1800,
    "slug": "behringer-wing-rack",
    "photo": "https://cdn-media.empowertribe.com/ffa208737935253e05edcd1ff66c092f/Image_BE_0604-AAE_WING-RACK_Media-Front.webp"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Behringer X32 Rack мікшер цифровий рековий",
    "price": 1400,
    "slug": "behringer-x32-rack-мікшер-цифровий-рековий",
    "photo": "https://cdn-media.empowertribe.com/58140a591498bca8a2bba3f81bfd30a3/Image_BE_0604-AAA_X32-RACK_Media-Front.webp"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Behringer XR18 мікшер цифровий рековий",
    "price": 1000,
    "slug": "behringer-xr18-мікшер-цифровий-рековий"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Midas M32R мікшер цифровий 22вх. 14вих.",
    "price": 2500,
    "slug": "midas-m32r-мікшер-цифровий-22вх-14вих",
    "photo": "https://cdn-media.empowertribe.com/d51fb8ff98e84a8abf1daba3b9950526/Image_MI_0603-AEF_M32R_Left_XL.png"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Midas DL32 стейджбокс цифровий 32вx. 16вих.",
    "price": 1300,
    "slug": "midas-dl32-стейджбокс-цифровий-32вx-16вих",
    "photo": "https://cdn-media.empowertribe.com/0c7e0812fc06409da9fc787b48922def/Image_MI_0606-ACR_DL32_Front_XL.png"
  },
  {
    "category": "Мікшерні пульти",
    "name": "RCF F10 XR Мікшерний пульт 4мік. 4 лін. Вх",
    "price": 500,
    "slug": "rcf-f10-xr-мікшерний-пульт-4мік-4-лін-вх"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Yamaha MG102c мікшерний пульт, 4мік., 2лін.вх",
    "price": 350,
    "slug": "yamaha-mg102c-мікшерний-пульт-4мік-2лінвх"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Yamaha MG12fx мікшерний пульт, 6мік., 6лін.вх",
    "price": 500,
    "slug": "yamaha-mg12fx-мікшерний-пульт-6мік-6лінвх"
  },
  {
    "category": "Мікшерні пульти",
    "name": "DBX DjDI Стерео дібокс пасивний",
    "price": 150,
    "slug": "dbx-djdi-стерео-дібокс-пасивний"
  },
  {
    "category": "Мікшерні пульти",
    "name": "LA Audio DBT Plus стерео дібокс пасивний",
    "price": 150,
    "slug": "la-audio-dbt-plus-стерео-дібокс-пасивний"
  },
  {
    "category": "Мікшерні пульти",
    "name": "IMG Stgeline DIB-100, дібокс пасивний, 1канал",
    "price": 150,
    "slug": "img-stgeline-dib-100-дібокс-пасивний-1канал"
  },
  {
    "category": "Мікшерні пульти",
    "name": "Yellow engineering, дібокс активний, 1 канал",
    "price": 150,
    "slug": "yellow-engineering-дібокс-активний-1-канал"
  },
  {
    "category": "Гітарне обладнання",
    "name": "Marshall AVT50х Гітарний комбо",
    "price": 500,
    "slug": "marshall-avt50х-гітарний-комбо"
  },
  {
    "category": "Гітарне обладнання",
    "name": "Ashdown MAG600  EVO III C410T бас гітарний комбо",
    "price": 1000,
    "slug": "ashdown-mag600-evo-iii-c410t-бас-гітарний-комбо"
  },
  {
    "category": "Ударні інструменти",
    "name": "Tama Starcalssic Walnut/birch 22х14,12х10,16х16,14х6,5 snare, колір ROY",
    "price": 2400,
    "slug": "tama-starcalssic-walnutbirch-22х1412х1016х1614х65-snare-колір-roy"
  },
  {
    "category": "Ударні інструменти",
    "name": "Sonor force 3007 Maple. 22х18, 10х8,12х9, 16х16, 14х5 snare, колір Red Wine",
    "price": 2000,
    "slug": "sonor-force-3007-maple-22х18-10х812х9-16х16-14х5-snare-колір-red-wine"
  },
  {
    "category": "Ударні інструменти",
    "name": "Drumshield, Екран для барабанів, вис. 180см, 5х50см. 6мм",
    "price": 800,
    "slug": "drumshield-екран-для-барабанів-вис-180см-5х50см-6мм"
  },
  {
    "category": "Мікрофони",
    "name": "Audix i5 Мікрофон інструментальний",
    "price": 100,
    "slug": "audix-i5-мікрофон-інструментальний"
  },
  {
    "category": "Мікрофони",
    "name": "Sennheiser E904 Барабанні мікрофони",
    "price": 1200,
    "slug": "sennheiser-e904-барабанні-мікрофони"
  },
  {
    "category": "Мікрофони",
    "name": "Audio-technica mb5k, Мікрофон інструментальний",
    "price": 100,
    "slug": "audio-technica-mb5k-мікрофон-інструментальний"
  },
  {
    "category": "Мікрофони",
    "name": "Shure А91 Барабанний мікрофон",
    "price": 300,
    "slug": "shure-а91-барабанний-мікрофон"
  },
  {
    "category": "Мікрофони",
    "name": "Shure PG81 Мікрофон інструментальний конд.",
    "price": 200,
    "slug": "shure-pg81-мікрофон-інструментальний-конд"
  },
  {
    "category": "Мікрофони",
    "name": "Shure Beta52A Мікрофон для Бас-бочки",
    "price": 200,
    "slug": "shure-beta52a-мікрофон-для-бас-бочки"
  },
  {
    "category": "Мікрофони",
    "name": "Shure Beta58a Мікрофон динамічний",
    "price": 250,
    "slug": "shure-beta58a-мікрофон-динамічний"
  },
  {
    "category": "Мікрофони",
    "name": "Shure SM57 Мікрофон інструментальний",
    "price": 200,
    "slug": "shure-sm57-мікрофон-інструментальний"
  },
  {
    "category": "Мікрофони",
    "name": "Shure SM58 Мікрофон динамічний",
    "price": 150,
    "slug": "shure-sm58-мікрофон-динамічний"
  },
  {
    "category": "Мікрофони",
    "name": "Shure SM86 Мікрофон динамічний",
    "price": 200,
    "slug": "shure-sm86-мікрофон-динамічний"
  },
  {
    "category": "Мікрофони",
    "name": "Se electronics V7 Мікрофон динамічний",
    "price": 200,
    "slug": "se-electronics-v7-мікрофон-динамічний"
  },
  {
    "category": "Безпровідні системи",
    "name": "Audio-Technika ATW 3100  Радіомікрофон, радіосистема",
    "price": 500,
    "slug": "audio-technika-atw-3100-радіомікрофон-радіосистема"
  },
  {
    "category": "Безпровідні системи",
    "name": "Audix RAD360, OM5 Радіомікрофон",
    "price": 400,
    "slug": "audix-rad360-om5-радіомікрофон"
  },
  {
    "category": "Безпровідні системи",
    "name": "Sennheiser XSW65 Радіомікрофон",
    "price": 500,
    "slug": "sennheiser-xsw65-радіомікрофон"
  },
  {
    "category": "Безпровідні системи",
    "name": "Sennheiser IEM G3 система персонального моніторингу",
    "price": 700,
    "slug": "sennheiser-iem-g3-система-персонального-моніторингу"
  },
  {
    "category": "Безпровідні системи",
    "name": "Shure ULXD SM58, L50 632-696MHz Мікрофон безпровідний",
    "price": 1000,
    "slug": "shure-ulxd-sm58-l50-632-696mhz-мікрофон-безпровідний"
  },
  {
    "category": "Стійки",
    "name": "Пюпітр складний Rockstand RS10010B",
    "price": 100,
    "slug": "пюпітр-складний-rockstand-rs10010b"
  },
  {
    "category": "Стійки",
    "name": "Пюпітр Soundking DF 013",
    "price": 150,
    "slug": "пюпітр-soundking-df-013"
  },
  {
    "category": "Стійки",
    "name": "Стійка для тарілки Tama RoadPro HC83BW , журавель, пряма",
    "price": 100,
    "slug": "стійка-для-тарілки-tama-roadpro-hc83bw-журавель-пряма"
  },
  {
    "category": "Стійки",
    "name": "Стійка для тарілки  Tama Stamgemaster HC60BW журавель",
    "price": 100,
    "slug": "стійка-для-тарілки-tama-stamgemaster-hc60bw-журавель"
  },
  {
    "category": "Стійки",
    "name": "Стійка для тарілки Mapex B800 журавель",
    "price": 100,
    "slug": "стійка-для-тарілки-mapex-b800-журавель"
  },
  {
    "category": "Стійки",
    "name": "Стійка для тарілки Gibraltar 5709 журавель",
    "price": 100,
    "slug": "стійка-для-тарілки-gibraltar-5709-журавель"
  },
  {
    "category": "Стійки",
    "name": "Стійка для тарілки Pearl BC930 журавель",
    "price": 100,
    "slug": "стійка-для-тарілки-pearl-bc930-журавель"
  },
  {
    "category": "Стійки",
    "name": "Стійка Hi-Hat Tama RoadPro HH75",
    "price": 150,
    "slug": "стійка-hi-hat-tama-roadpro-hh75"
  },
  {
    "category": "Стійки",
    "name": "Стійка для малого барабана Tama RoadPro HS80W",
    "price": 100,
    "slug": "стійка-для-малого-барабана-tama-roadpro-hs80w"
  },
  {
    "category": "Стійки",
    "name": "Стійка для малого барабана Gibraltar 4706",
    "price": 100,
    "slug": "стійка-для-малого-барабана-gibraltar-4706"
  },
  {
    "category": "Стійки",
    "name": "Стілець для барабанів Millenium",
    "price": 100,
    "slug": "стілець-для-барабанів-millenium"
  },
  {
    "category": "Стійки",
    "name": "Стійка для мікрофону K&M, журавель",
    "price": 100,
    "slug": "стійка-для-мікрофону-km-журавель"
  },
  {
    "category": "Стійки",
    "name": "Стійка для мікрофону Gravity MS4321B журавель, чорна",
    "price": 100,
    "slug": "стійка-для-мікрофону-gravity-ms4321b-журавель-чорна"
  },
  {
    "category": "Стійки",
    "name": "Стійка для мікрофону, Gravity MS 23W пряма, біла, 100 - 160см.",
    "price": 300,
    "slug": "стійка-для-мікрофону-gravity-ms-23w-пряма-біла-100-160см"
  },
  {
    "category": "Стійки",
    "name": "Стійка для мікрофону, Gravity MS 23W пряма, чорна, 100 - 160см.",
    "price": 150,
    "slug": "стійка-для-мікрофону-gravity-ms-23w-пряма-чорна-100-160см"
  },
  {
    "category": "Стійки",
    "name": "Стійка для мікрофону низька",
    "price": 100,
    "slug": "стійка-для-мікрофону-низька"
  },
  {
    "category": "Стійки",
    "name": "Стійка для акустичних систем",
    "price": 100,
    "slug": "стійка-для-акустичних-систем"
  },
  {
    "category": "Стійки",
    "name": "Стійка саб-топ 32мм",
    "price": 100,
    "slug": "стійка-саб-топ-32мм"
  },
  {
    "category": "Стійки",
    "name": "Стійка для клавішних Soundking, чорна",
    "price": 100,
    "slug": "стійка-для-клавішних-soundking-чорна"
  },
  {
    "category": "Стійки",
    "name": "Стійка для клавішних Х-подібна подвійна Gravity KS X2, чорна",
    "price": 150,
    "slug": "стійка-для-клавішних-х-подібна-подвійна-gravity-ks-x2-чорна"
  },
  {
    "category": "Стійки",
    "name": "Стійка для клавішних Х-подібна подвійна Gravity KS X2W, біла",
    "price": 300,
    "slug": "стійка-для-клавішних-х-подібна-подвійна-gravity-ks-x2w-біла"
  },
  {
    "category": "Стійки",
    "name": "Стійка для гітари Gravity GS 01 NHB",
    "price": 100,
    "slug": "стійка-для-гітари-gravity-gs-01-nhb"
  },
  {
    "category": "Стійки",
    "name": "Стійка для гітари",
    "price": 100,
    "slug": "стійка-для-гітари"
  },
  {
    "category": "Світлове обладнання",
    "name": "LED Par Free Color 18x10W RGBW",
    "price": 200,
    "slug": "led-par-free-color-18x10w-rgbw"
  },
  {
    "category": "Світлове обладнання",
    "name": "LED Bar Free Color 14x30W RGBWАС+ UV",
    "price": 300,
    "slug": "led-bar-free-color-14x30w-rgbwас-uv"
  },
  {
    "category": "Світлове обладнання",
    "name": "LED COB 200W",
    "price": 500,
    "slug": "led-cob-200w"
  },
  {
    "category": "Світлове обладнання",
    "name": "Prolux moving strobe",
    "price": 900,
    "slug": "prolux-moving-strobe"
  },
  {
    "category": "Світлове обладнання",
    "name": "Prolux K15 Голова рухома",
    "price": 1200,
    "slug": "prolux-k15-голова-рухома"
  },
  {
    "category": "Світлове обладнання",
    "name": "Beam 230W 7R Голова рухома",
    "price": 800,
    "slug": "beam-230w-7r-голова-рухома"
  },
  {
    "category": "Світлове обладнання",
    "name": "Blinder 4 (4*650W) Прожектор ударного світла",
    "price": 500,
    "slug": "blinder-4-4650w-прожектор-ударного-світла"
  },
  {
    "category": "Світлове обладнання",
    "name": "Dl light DMX 512 Діммерний модуль 4-ти канальний по 800W",
    "price": 500,
    "slug": "dl-light-dmx-512-діммерний-модуль-4-ти-канальний-по-800w"
  },
  {
    "category": "Світлове обладнання",
    "name": "Strobe 1500 DMX Стробоскоп",
    "price": 400,
    "slug": "strobe-1500-dmx-стробоскоп"
  },
  {
    "category": "Світлове обладнання",
    "name": "DMX 512 Mixer 192ch+wireless Dmx+Battery",
    "price": 300,
    "slug": "dmx-512-mixer-192chwireless-dmxbattery"
  },
  {
    "category": "Світлове обладнання",
    "name": "USB DMX + Ноутбук GrandMa OnPC",
    "price": 500,
    "slug": "usb-dmx-ноутбук-grandma-onpc"
  },
  {
    "category": "Світлове обладнання",
    "name": "GrandMa Command Wing",
    "price": 1600,
    "slug": "grandma-command-wing"
  },
  {
    "category": "Світлове обладнання",
    "name": "GrandMa Fader Wing",
    "price": 1400,
    "slug": "grandma-fader-wing"
  },
  {
    "category": "Світлове обладнання",
    "name": "MagiQ mini wing",
    "price": 1000,
    "slug": "magiq-mini-wing"
  },
  {
    "category": "Світлове обладнання",
    "name": "DMX Spliter 8 ch",
    "price": 300,
    "slug": "dmx-spliter-8-ch"
  },
  {
    "category": "Світлове обладнання",
    "name": "ArtNet 8 universe 4096 каналів",
    "price": 500,
    "slug": "artnet-8-universe-4096-каналів"
  },
  {
    "category": "Світлове обладнання",
    "name": "Генератор диму 1500W",
    "price": 450,
    "slug": "генератор-диму-1500w"
  },
  {
    "category": "Світлове обладнання",
    "name": "HAZER MH1500 Water Based Генератор туману",
    "price": 600,
    "slug": "hazer-mh1500-water-based-генератор-туману"
  },
  {
    "category": "Світлове обладнання",
    "name": "HAZER Oil Based Генератор туману",
    "price": 800,
    "slug": "hazer-oil-based-генератор-туману"
  },
  {
    "category": "Світлове обладнання",
    "name": "Стійка для світла (Т-подібна) 2,5м, до 30кг",
    "price": 150,
    "slug": "стійка-для-світла-т-подібна-25м-до-30кг"
  },
  {
    "category": "Світлове обладнання",
    "name": "Стійка для світла з лебідкою, макс.висота 4м, до 80кг",
    "price": 400,
    "slug": "стійка-для-світла-з-лебідкою-максвисота-4м-до-80кг"
  },
  {
    "category": "Світлове обладнання",
    "name": "Ферма для світлових приборів 290х290, 1м",
    "price": 150,
    "slug": "ферма-для-світлових-приборів-290х290-1м"
  },
  {
    "category": "Світлове обладнання",
    "name": "Ферма для світлових приборів 290х290, куб зєднувальний",
    "price": 300,
    "slug": "ферма-для-світлових-приборів-290х290-куб-зєднувальний"
  },
  {
    "category": "Світлове обладнання",
    "name": "Платформа (основа) 60*60 для ферми",
    "price": 200,
    "slug": "платформа-основа-6060-для-ферми"
  },
  {
    "category": "Світлове обладнання",
    "name": "Дзеркальна куля 30см",
    "price": 700,
    "slug": "дзеркальна-куля-30см"
  },
  {
    "category": "Світлове обладнання",
    "name": "Задник чорний 3х4м",
    "price": 400,
    "slug": "задник-чорний-3х4м"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Подіум Prolyte 2x1м. Висота 20, 25, 50, 100см",
    "price": 700,
    "slug": "подіум-prolyte-2x1м-висота-20-25-50-100см"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Покриття ковролін 1кв.м",
    "price": 200,
    "slug": "покриття-ковролін-1квм"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Покриття червона доріжка 1м",
    "price": 100,
    "slug": "покриття-червона-доріжка-1м"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Сцена 6x4, вис. 4—6м.,подіум 1,2м, портал 2м, чорний кабінет",
    "price": 12000,
    "slug": "сцена-6x4-вис-46мподіум-12м-портал-2м-чорний-кабінет"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Сцена 6х8, вис. 6м , подіум 1,2м, портал 2м чорний кабінет",
    "price": 16000,
    "slug": "сцена-6х8-вис-6м-подіум-12м-портал-2м-чорний-кабінет"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Сцена 10х12 вис. 6м,  арка",
    "price": 24000,
    "slug": "сцена-10х12-вис-6м-арка"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Настил  2х1м, фанера 21мм",
    "price": 200,
    "slug": "настил-2х1м-фанера-21мм"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Сходи для подіуму 50-150см",
    "price": 700,
    "slug": "сходи-для-подіуму-50-150см"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Таль ланцюгова 6м, 1000кг.",
    "price": 450,
    "slug": "таль-ланцюгова-6м-1000кг"
  },
  {
    "category": "Сценічне обладнання",
    "name": "Вентилятор підлоговий Wildwind isf3510",
    "price": 250,
    "slug": "вентилятор-підлоговий-wildwind-isf3510"
  },
  {
    "category": "DJ Обладнання",
    "name": "Ширма для DJ чорна, 125х50cм(4секції)",
    "price": 300,
    "slug": "ширма-для-dj-чорна-125х50cм4секції"
  },
  {
    "category": "DJ Обладнання",
    "name": "Ширма для DJ біла, 120х50см(4секції)",
    "price": 300,
    "slug": "ширма-для-dj-біла-120х50см4секції"
  },
  {
    "category": "Мультимедія",
    "name": "Презентер Logitech h400",
    "price": 200,
    "slug": "презентер-logitech-h400"
  },
  {
    "category": "Мультимедія",
    "name": "Проектор ламповий HDMI/VGA",
    "price": 500,
    "slug": "проектор-ламповий-hdmivga"
  },
  {
    "category": "Мультимедія",
    "name": "led Екран 3*2м",
    "price": 20000,
    "slug": "led-екран-32м"
  },
  {
    "category": "Мультимедія",
    "name": "Телевізор TCL діагональ 55”, 4K, + стійка (тринога)",
    "price": 1000,
    "slug": "телевізор-tcl-діагональ-55-4k-стійка-тринога"
  },
  {
    "category": "Мультимедія",
    "name": "Телевізор Samsung UE55NU7179U, діаг. 55”, 4K, + стійка (тринога)",
    "price": 1000,
    "slug": "телевізор-samsung-ue55nu7179u-діаг-55-4k-стійка-тринога"
  },
  {
    "category": "Мультимедія",
    "name": "Телевізор Samsung UE58NU7179U, діаг. 58”, 4K, + стійка KSL PS1",
    "price": 1500,
    "slug": "телевізор-samsung-ue58nu7179u-діаг-58-4k-стійка-ksl-ps1"
  },
  {
    "category": "Мультимедія",
    "name": "Телевізор Samsung GQ65Q60RGT, діаг. 65”, 4K, QLED + стійка KSL PS1",
    "price": 2300,
    "slug": "телевізор-samsung-gq65q60rgt-діаг-65-4k-qled-стійка-ksl-ps1"
  },
  {
    "category": "Мультимедія",
    "name": "Wireless HDMI Transmitter 1шт + Reciever 2шт , 5,8Gz до 30м. Безпровідний HDMI, комплект",
    "price": 600,
    "slug": "wireless-hdmi-transmitter-1шт-reciever-2шт-58gz-до-30м-безпровідний-hdmi-комплект"
  },
  {
    "category": "Мультимедія",
    "name": "Сплітер HDMI активний 1х2, 1x4",
    "price": 150,
    "slug": "сплітер-hdmi-активний-1х2-1x4"
  },
  {
    "category": "Мультимедія",
    "name": "Стійка презентаційна KSL PS1",
    "price": 300,
    "slug": "стійка-презентаційна-ksl-ps1"
  },
  {
    "category": "Комутація",
    "name": "Кабель XLR-XLR (0,5-10м)",
    "price": 15,
    "slug": "кабель-xlr-xlr-05-10м"
  },
  {
    "category": "Комутація",
    "name": "Кабель 6,3 jack",
    "price": 15,
    "slug": "кабель-63-jack"
  },
  {
    "category": "Комутація",
    "name": "Подовжжувач 3х2,5 16A 220V (1-15м)",
    "price": 15,
    "slug": "подовжжувач-3х25-16a-220v-1-15м"
  },
  {
    "category": "Комутація",
    "name": "Кабель силовий 3х6 32A 220V (м)",
    "price": 20,
    "slug": "кабель-силовий-3х6-32a-220v-м"
  },
  {
    "category": "Комутація",
    "name": "Кабель силовий 5х4 32A 380V (м)",
    "price": 20,
    "slug": "кабель-силовий-5х4-32a-380v-м"
  },
  {
    "category": "Комутація",
    "name": "Розпридільний блок 220V 32A",
    "price": 350,
    "slug": "розпридільний-блок-220v-32a"
  },
  {
    "category": "Комутація",
    "name": "Розпридільний блок 380-220V 32A",
    "price": 450,
    "slug": "розпридільний-блок-380-220v-32a"
  },
  {
    "category": "Комутація",
    "name": "Кабель CAT5 Roxtone 30м.",
    "price": 300,
    "slug": "кабель-cat5-roxtone-30м"
  },
  {
    "category": "Комутація",
    "name": "Кабель CAT5 Roxtone 70м.",
    "price": 700,
    "slug": "кабель-cat5-roxtone-70м"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Транспортні послуги по місту",
    "price": 1000,
    "slug": "транспортні-послуги-по-місту"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Монтажно-демонтажні роботи",
    "price": 1800,
    "slug": "монтажно-демонтажні-роботи"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Робота оператора по світлу",
    "price": 2000,
    "slug": "робота-оператора-по-світлу"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Робота звукооператора",
    "price": 2000,
    "slug": "робота-звукооператора"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Робота техніка (stageman)",
    "price": 1800,
    "slug": "робота-техніка-stageman"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "DJ",
    "price": 4000,
    "slug": "dj"
  },
  {
    "category": "Транспортні послуги вант.",
    "name": "Інші витрати",
    "price": 0,
    "slug": "інші-витрати"
  }
];

const grid = document.getElementById("catalogGrid");
const search = document.getElementById("search");
const categoryFilter = document.getElementById("categoryFilter");
const emptyState = document.getElementById("emptyState");

const categories = [...new Set(equipment.map(x => x.category))];
categories.forEach(cat => {
  const opt = document.createElement("option");
  opt.value = cat;
  opt.textContent = cat;
  categoryFilter.appendChild(opt);
});

function money(n) {
  return new Intl.NumberFormat("uk-UA").format(n);
}

function storageKey(item) {
  return "stagebox-photo-" + item.slug;
}

function getStoredPhoto(item) {
  try { return localStorage.getItem(storageKey(item)); } catch(e) { return null; }
}

function render() {
  const q = search.value.trim().toLowerCase();
  const cat = categoryFilter.value;

  const filtered = equipment.filter(item =>
    (cat === "all" || item.category === cat) &&
    (!q || (item.name + " " + item.category).toLowerCase().includes(q))
  );

  grid.innerHTML = "";
  emptyState.hidden = filtered.length !== 0;

  filtered.forEach(item => {
    const card = document.createElement("article");
    card.className = "catalog-card";

    const photo = document.createElement("div");
    photo.className = "equipment-photo";

    const stored = getStoredPhoto(item);
    const img = document.createElement("img");
    img.alt = item.name;
    img.loading = "lazy";
    img.src = stored || item.photo || ("images/equipment/" + item.slug + ".jpg");

    const placeholder = document.createElement("div");
    placeholder.className = "placeholder";
    placeholder.innerHTML = "STAGEBOX<span>ДОДАЙТЕ ФОТО ОБЛАДНАННЯ</span>";
    placeholder.style.display = "none";

    img.onerror = () => {
      img.style.display = "none";
      placeholder.style.display = "grid";
    };
    if (stored) img.onerror = null;

    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";
    file.hidden = true;

    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "photo-edit";
    edit.textContent = "📷 Змінити фото";
    edit.onclick = () => file.click();

    file.onchange = () => {
      const selected = file.files && file.files[0];
      if (!selected) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          localStorage.setItem(storageKey(item), reader.result);
          img.src = reader.result;
          img.style.display = "block";
          placeholder.style.display = "none";
        } catch(e) {
          alert("Фото завелике для збереження в браузері. Для постійного фото покладіть файл у папку images/equipment/ з назвою: " + item.slug + ".jpg");
        }
      };
      reader.readAsDataURL(selected);
    };

    photo.append(img, placeholder, edit, file);

    const body = document.createElement("div");
    body.className = "card-body";
    body.innerHTML = `
      <div class="tag">${item.category}</div>
      <h3>${escapeHtml(item.name)}</h3>
      <div class="price">${money(item.price)} <small>грн / шт.</small></div>
    `;

    card.append(photo, body);
    grid.appendChild(card);
  });
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

search.addEventListener("input", render);
categoryFilter.addEventListener("change", render);
render();
